public class Main {
    public static void main(String[] args) {
        Student s1 = new Student("John Doe", 2002, 2025, "S123", "Business IT");
        s1.displayDetails();
    }
}
